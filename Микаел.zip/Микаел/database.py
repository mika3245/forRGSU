import sqlite3
from datetime import datetime

class DiaryDatabase:
    def __init__(self, db_name="diary.db"):
        self.db_name = db_name
        self.init_database()
    
    def init_database(self):
        """Инициализация базы данных и создание таблиц"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS entries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                date_created TEXT NOT NULL,
                mood TEXT,
                tags TEXT
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def add_entry(self, title, content, mood="", tags=""):
        """Добавление новой записи в дневник"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        current_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        cursor.execute('''
            INSERT INTO entries (title, content, date_created, mood, tags)
            VALUES (?, ?, ?, ?, ?)
        ''', (title, content, current_date, mood, tags))
        
        conn.commit()
        entry_id = cursor.lastrowid
        conn.close()
        
        return entry_id
    
    def get_all_entries(self):
        """Получение всех записей из дневника"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, title, content, date_created, mood, tags 
            FROM entries 
            ORDER BY date_created DESC
        ''')
        
        entries = cursor.fetchall()
        conn.close()
        
        return entries
    
    def get_entry_by_id(self, entry_id):
        """Получение записи по ID"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, title, content, date_created, mood, tags 
            FROM entries 
            WHERE id = ?
        ''', (entry_id,))
        
        entry = cursor.fetchone()
        conn.close()
        
        return entry
    
    def update_entry(self, entry_id, title, content, mood="", tags=""):
        """Обновление существующей записи"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE entries 
            SET title = ?, content = ?, mood = ?, tags = ?
            WHERE id = ?
        ''', (title, content, mood, tags, entry_id))
        
        conn.commit()
        conn.close()
        
        return True
    
    def delete_entry(self, entry_id):
        """Удаление записи"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        cursor.execute('DELETE FROM entries WHERE id = ?', (entry_id,))
        
        conn.commit()
        conn.close()
        
        return True
    
    def search_entries(self, keyword):
        """Поиск записей по ключевому слову"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, title, content, date_created, mood, tags 
            FROM entries 
            WHERE title LIKE ? OR content LIKE ? OR tags LIKE ?
            ORDER BY date_created DESC
        ''', (f'%{keyword}%', f'%{keyword}%', f'%{keyword}%'))
        
        entries = cursor.fetchall()
        conn.close()
        
        return entries
    
    def get_entries_by_date(self, date):
        """Получение записей по конкретной дате"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, title, content, date_created, mood, tags 
            FROM entries 
            WHERE date(date_created) = date(?)
            ORDER BY date_created DESC
        ''', (date,))
        
        entries = cursor.fetchall()
        conn.close()
        
        return entries