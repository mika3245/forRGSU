from database import DiaryDatabase
from datetime import datetime

class DiaryApp:
    def __init__(self):
        self.db = DiaryDatabase()
    
    def display_menu(self):
        """Отображение главного меню"""
        print("\n" + "="*50)
        print("           ЛИЧНЫЙ ДНЕВНИК")
        print("="*50)
        print("1. Добавить новую запись")
        print("2. Просмотреть все записи")
        print("3. Найти запись")
        print("4. Редактировать запись")
        print("5. Удалить запись")
        print("6. Просмотреть записи за дату")
        print("7. Выйти")
        print("="*50)
    
    def add_entry(self):
        """Добавление новой записи"""
        print("\n--- Новая запись ---")
        title = input("Заголовок: ").strip()
        
        if not title:
            print("Заголовок не может быть пустым!")
            return
        
        print("Содержание (введите 'END' на новой строке для завершения):")
        content_lines = []
        while True:
            line = input()
            if line.strip() == 'END':
                break
            content_lines.append(line)
        
        content = '\n'.join(content_lines)
        
        mood = input("Настроение (опционально): ").strip()
        tags = input("Теги (через запятую, опционально): ").strip()
        
        entry_id = self.db.add_entry(title, content, mood, tags)
        print(f"\nЗапись успешно добавлена! ID: {entry_id}")
    
    def view_all_entries(self):
        """Просмотр всех записей"""
        entries = self.db.get_all_entries()
        
        if not entries:
            print("\nЗаписей пока нет!")
            return
        
        print(f"\n--- Все записи ({len(entries)}) ---")
        for entry in entries:
            self.display_entry_preview(entry)
    
    def display_entry_preview(self, entry):
        """Отображение краткой информации о записи"""
        id, title, content, date_created, mood, tags = entry
        
        # Форматируем дату для лучшего отображения
        created_dt = datetime.strptime(date_created, "%Y-%m-%d %H:%M:%S")
        formatted_date = created_dt.strftime("%d.%m.%Y %H:%M")
        
        # Обрезаем контент для предпросмотра
        preview_content = content[:100] + "..." if len(content) > 100 else content
        
        print(f"\n[{id}] {title}")
        print(f"📅 {formatted_date}")
        if mood:
            print(f"😊 Настроение: {mood}")
        if tags:
            print(f"🏷️ Теги: {tags}")
        print(f"📝 {preview_content}")
        print("-" * 50)
    
    def display_full_entry(self, entry):
        """Отображение полной информации о записи"""
        id, title, content, date_created, mood, tags = entry
        
        created_dt = datetime.strptime(date_created, "%Y-%m-%d %H:%M:%S")
        formatted_date = created_dt.strftime("%d.%m.%Y %H:%M")
        
        print(f"\n" + "="*60)
        print(f"ЗАПИСЬ #{id}")
        print("="*60)
        print(f"📖 Заголовок: {title}")
        print(f"📅 Дата: {formatted_date}")
        if mood:
            print(f"😊 Настроение: {mood}")
        if tags:
            print(f"🏷️ Теги: {tags}")
        print(f"\n📝 Содержание:")
        print("-" * 60)
        print(content)
        print("-" * 60)
    
    def search_entries(self):
        """Поиск записей"""
        keyword = input("\nВведите ключевое слово для поиска: ").strip()
        
        if not keyword:
            print("Ключевое слово не может быть пустым!")
            return
        
        entries = self.db.search_entries(keyword)
        
        if not entries:
            print(f"\nЗаписей с ключевым словом '{keyword}' не найдено!")
            return
        
        print(f"\n--- Найдено записей: {len(entries)} ---")
        for entry in entries:
            self.display_entry_preview(entry)
    
    def edit_entry(self):
        """Редактирование записи"""
        try:
            entry_id = int(input("\nВведите ID записи для редактирования: "))
        except ValueError:
            print("Некорректный ID!")
            return
        
        entry = self.db.get_entry_by_id(entry_id)
        
        if not entry:
            print(f"Запись с ID {entry_id} не найдена!")
            return
        
        self.display_full_entry(entry)
        
        print("\n--- Редактирование записи ---")
        new_title = input(f"Новый заголовок [{entry[1]}]: ").strip() or entry[1]
        
        print("Новое содержание (введите 'END' на новой строке для завершения):")
        print("Текущее содержание:")
        print(entry[2])
        print("\nВведите новое содержание:")
        
        content_lines = []
        while True:
            line = input()
            if line.strip() == 'END':
                break
            content_lines.append(line)
        
        new_content = '\n'.join(content_lines) if content_lines else entry[2]
        new_mood = input(f"Новое настроение [{entry[4] or 'нет'}]: ").strip() or entry[4]
        new_tags = input(f"Новые теги [{entry[5] or 'нет'}]: ").strip() or entry[5]
        
        self.db.update_entry(entry_id, new_title, new_content, new_mood, new_tags)
        print("Запись успешно обновлена!")
    
    def delete_entry(self):
        """Удаление записи"""
        try:
            entry_id = int(input("\nВведите ID записи для удаления: "))
        except ValueError:
            print("Некорректный ID!")
            return
        
        entry = self.db.get_entry_by_id(entry_id)
        
        if not entry:
            print(f"Запись с ID {entry_id} не найдена!")
            return
        
        self.display_entry_preview(entry)
        
        confirm = input(f"\nВы уверены, что хотите удалить запись #{entry_id}? (y/N): ").strip().lower()
        
        if confirm == 'y':
            self.db.delete_entry(entry_id)
            print("Запись успешно удалена!")
        else:
            print("Удаление отменено.")
    
    def view_entries_by_date(self):
        """Просмотр записей за конкретную дату"""
        date_str = input("\nВведите дату (ГГГГ-ММ-ДД): ").strip()
        
        try:
            # Проверяем корректность даты
            datetime.strptime(date_str, "%Y-%m-%d")
        except ValueError:
            print("Некорректный формат даты! Используйте ГГГГ-ММ-ДД")
            return
        
        entries = self.db.get_entries_by_date(date_str)
        
        if not entries:
            print(f"\nЗаписей за {date_str} не найдено!")
            return
        
        print(f"\n--- Записи за {date_str} ({len(entries)}) ---")
        for entry in entries:
            self.display_entry_preview(entry)
    
    def run(self):
        """Запуск приложения"""
        print("Добро пожаловать в ваш личный дневник!")
        
        while True:
            self.display_menu()
            
            try:
                choice = input("\nВыберите действие (1-7): ").strip()
                
                if choice == '1':
                    self.add_entry()
                elif choice == '2':
                    self.view_all_entries()
                elif choice == '3':
                    self.search_entries()
                elif choice == '4':
                    self.edit_entry()
                elif choice == '5':
                    self.delete_entry()
                elif choice == '6':
                    self.view_entries_by_date()
                elif choice == '7':
                    print("\nДо свидания! Ваши записи сохранены.")
                    break
                else:
                    print("Неверный выбор! Пожалуйста, выберите от 1 до 7.")
            
            except KeyboardInterrupt:
                print("\n\nПрограмма прервана пользователем. До свидания!")
                break
            except Exception as e:
                print(f"\nПроизошла ошибка: {e}")