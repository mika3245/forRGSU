from diary import DiaryApp

def main():
    """Главная функция для запуска приложения"""
    app = DiaryApp()
    app.run()

if __name__ == "__main__":
    main()